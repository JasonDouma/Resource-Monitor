#include <iostream>
#include <string>
#include <vector>
#include <atomic>
#include <thread>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <chrono>

#ifdef _WIN32
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <pdh.h>
#include <psapi.h>
#include <tlhelp32.h>
#include <comdef.h>
#include <Wbemidl.h>
#pragma comment(lib, "pdh.lib")
#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "wbemuuid.lib")
#define OS_NAME "Windows"
#endif
#elif defined(__linux__)
#include <sys/sysinfo.h>
  #include <sys/statvfs.h>
  #include <dirent.h>
  #include <fstream>
  #define OS_NAME "Linux"
#elif defined(__APPLE__)
#include <sys/sysctl.h>
#include <sys/param.h>
#include <sys/mount.h>
#include <mach/mach.h>
#include <mach/processor_info.h>
#include <mach/mach_host.h>
#include <libproc.h>
#include <sys/proc_info.h>
#define OS_NAME "macOS"
#else
#define OS_NAME "Unknown"
#endif
#ifdef _WIN32
using pid_t = DWORD;
#else
using pid_t = int;
#endif

std::atomic<bool> advancedMode(false), running(true);

struct ProcessInfo {
    std::string name;
    pid_t pid;
    double memoryUsage;
};
struct SystemInfo { std::string cpuModel, gpuModel; int totalCores; double totalRamGB, totalDiskGB; };
struct SystemMetrics { double cpuUsage, ramUsage, ramTotal, diskUsage, diskTotal, gpuUsage; std::vector<ProcessInfo> topProcesses; };

#ifdef _WIN32
PDH_HQUERY cpuQuery;
PDH_HCOUNTER cpuTotal;
std::string getCpuModel() {
    FILE* pipe = _popen("wmic cpu get Name", "r");
    if (!pipe) return "Unknown CPU";
    char buf[256]; std::string out;
    while (fgets(buf, sizeof(buf), pipe)) out += buf;
    _pclose(pipe);
    size_t pos = out.find('\n');
    if (pos != std::string::npos) out = out.substr(pos + 1);
    out.erase(std::remove(out.begin(), out.end(), '\r'), out.end());
    out.erase(std::remove(out.begin(), out.end(), '\n'), out.end());
    return out.empty() ? "Unknown CPU" : out;
}

double getCpuUsage() {
    PdhCollectQueryData(cpuQuery);
    PDH_FMT_COUNTERVALUE val;
    PdhGetFormattedCounterValue(cpuTotal, PDH_FMT_DOUBLE, nullptr, &val);
    return std::clamp(val.doubleValue, 0.0, 100.0);
}

std::pair<double,double> getRamUsage() {
    MEMORYSTATUSEX m{sizeof(m)};
    GlobalMemoryStatusEx(&m);
    double total = m.ullTotalPhys/1e9;
    double used = (m.ullTotalPhys - m.ullAvailPhys)/1e9;
    return {100.0 * used / total, total};
}

std::pair<double,double> getDiskUsage() {
    ULARGE_INTEGER freeB, totalB, dummy;
    GetDiskFreeSpaceExW(L"C:\\", &freeB, &totalB, &dummy);
    double total = totalB.QuadPart/1e9;
    double used = total - freeB.QuadPart/1e9;
    return {100.0 * used / total, total};
}

std::vector<ProcessInfo> getTopProcesses(int count=10) {
    std::vector<ProcessInfo> procs;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32 pe{sizeof(pe)};
    for (BOOL ok = Process32First(snap,&pe); ok; ok = Process32Next(snap,&pe)) {
        HANDLE h = OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ, FALSE, pe.th32ProcessID);
        if (h) {
            PROCESS_MEMORY_COUNTERS pm;
            GetProcessMemoryInfo(h, &pm, sizeof(pm));
            double mb = pm.WorkingSetSize/1e6;
            if (mb > 0.1) procs.push_back({pe.szExeFile, pe.th32ProcessID, mb});
            CloseHandle(h);
        }
    }
    CloseHandle(snap);
    std::sort(procs.begin(), procs.end(), [](auto &a, auto &b){ return a.memoryUsage > b.memoryUsage; });
    if (procs.size() > size_t(count)) procs.resize(count);
    return procs;
}

std::string getGpuModel() {
    HRESULT hres = CoInitializeEx(0, COINIT_MULTITHREADED);
    if (FAILED(hres)) return "Unknown GPU";

    hres = CoInitializeSecurity(NULL, -1, NULL, NULL, RPC_C_AUTHN_LEVEL_DEFAULT,
                                RPC_C_IMP_LEVEL_IMPERSONATE, NULL, EOAC_NONE, NULL);
    if (FAILED(hres)) {
        CoUninitialize();
        return "Unknown GPU";
    }

    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(CLSID_WbemLocator, 0, CLSCTX_INPROC_SERVER,
                            IID_IWbemLocator, (LPVOID *)&pLoc);
    if (FAILED(hres)) {
        CoUninitialize();
        return "Unknown GPU";
    }

    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(_bstr_t(L"ROOT\\CIMV2"), NULL, NULL, 0,
                               NULL, 0, 0, &pSvc);
    if (FAILED(hres)) {
        pLoc->Release();
        CoUninitialize();
        return "Unknown GPU";
    }

    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"),
        bstr_t("SELECT Name FROM Win32_VideoController"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
        NULL, &pEnumerator);

    std::string gpuName = "Unknown GPU";

    if (SUCCEEDED(hres)) {
        IWbemClassObject *pclsObj = NULL;
        ULONG uReturn = 0;

        if (pEnumerator) {
            while (pEnumerator) {
                HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
                if (!uReturn) break;

                VARIANT vtProp;
                hr = pclsObj->Get(L"Name", 0, &vtProp, 0, 0);
                if (SUCCEEDED(hr)) {
                    gpuName = _bstr_t(vtProp.bstrVal);
                    VariantClear(&vtProp);
                }

                pclsObj->Release();
            }
            pEnumerator->Release();
        }
    }

    pSvc->Release();
    pLoc->Release();
    CoUninitialize();
    return gpuName;
}
#endif

#ifdef __linux__
double getCpuUsage() {
    static unsigned long long lastIdle = 0, lastTotal = 0;
    std::ifstream f("/proc/stat");
    std::string line;
    std::getline(f, line);
    std::istringstream ss(line);
    ss.ignore(5);
    unsigned long long user, nice, system, idle, iow, irq, softirq, steal;
    ss >> user >> nice >> system >> idle >> iow >> irq >> softirq >> steal;
    unsigned long long idleAll = idle + iow;
    unsigned long long tot = user + nice + system + idleAll + irq + softirq + steal;
    unsigned long long diffIdle = idleAll - lastIdle;
    unsigned long long diffTot = tot - lastTotal;
    lastIdle = idleAll; lastTotal = tot;
    return diffTot ? 100.0 * (1.0 - (double)diffIdle / diffTot) : 0;
}

std::pair<double,double> getRamUsage() {
    struct sysinfo si;
    sysinfo(&si);
    double total = si.totalram * si.mem_unit / 1e9;
    double free = si.freeram * si.mem_unit / 1e9;
    return {100.0 * (total - free) / total, total};
}

std::pair<double,double> getDiskUsage() {
    struct statvfs fs;
    statvfs("/", &fs);
    double total = double(fs.f_blocks) * fs.f_frsize / 1e9;
    double free = double(fs.f_bfree) * fs.f_frsize / 1e9;
    return {100.0 * (total - free) / total, total};
}

std::vector<ProcessInfo> getTopProcesses(int count=10) {
    std::vector<ProcessInfo> procs;
    DIR* dir = opendir("/proc");
    struct dirent* ent;
    while ((ent = readdir(dir))) {
        if (!isdigit(ent->d_name[0])) continue;
        int pid = atoi(ent->d_name);
        std::ifstream f("/proc/"+std::to_string(pid)+"/status");
        std::string name; std::getline(f, name);
        f.seekg(0);
        std::string line;
        double vmrss = 0;
        while (std::getline(f, line)) if (line.find("VmRSS:")==0) {
            vmrss = std::stod(line.substr(6)) / 1024.0;
            break;
        }
        if (vmrss > 0.1) procs.push_back({name, pid, vmrss});
    }
    closedir(dir);
    std::sort(procs.begin(), procs.end(), [](auto &a, auto &b){ return a.memoryUsage > b.memoryUsage; });
    if (procs.size() > size_t(count)) procs.resize(count);
    return procs;
}
#endif

#ifdef __APPLE__
double getCpuUsage() {
    processor_cpu_load_info_t info;
    mach_msg_type_number_t cnt;
    natural_t nproc;
    host_processor_info(mach_host_self(), PROCESSOR_CPU_LOAD_INFO, &nproc, (processor_info_array_t*)&info, &cnt);
    unsigned long long user=0, sys=0, idle=0, nice=0;
    for (unsigned i = 0; i < nproc; ++i) {
        user += info[i].cpu_ticks[0];
        sys  += info[i].cpu_ticks[2];
        idle += info[i].cpu_ticks[1];
        nice += info[i].cpu_ticks[3];
    }
    vm_deallocate(mach_task_self(), (vm_address_t)info, cnt);
    unsigned long long total = user+sys+idle+nice;
    return total ? 100.0 * (1.0 - (double)idle / total) : 0;
}

std::pair<double,double> getRamUsage() {
    vm_statistics64_data_t v; mach_msg_type_number_t cnt = HOST_VM_INFO64_COUNT;
    host_statistics64(mach_host_self(), HOST_VM_INFO64, (host_info64_t)&v, &cnt);
    vm_size_t ps;
    host_page_size(mach_host_self(), &ps);
    double total = (v.active_count + v.inactive_count + v.wire_count + v.free_count) * ps / 1e9;
    double used = (v.active_count + v.wire_count) * ps / 1e9;
    return {100.0 * used / total, total};
}

std::pair<double,double> getDiskUsage() {
    struct statfs fs;
    statfs("/", &fs);
    double total = double(fs.f_blocks) * fs.f_bsize / 1e9;
    double free = double(fs.f_bfree) * fs.f_bsize / 1e9;
    return {100.0 * (total - free) / total, total};
}

std::vector<ProcessInfo> getTopProcesses(int count=10) {
    int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0};
    size_t size = 0;
    sysctl(mib,4,nullptr,&size,nullptr,0);
    auto procs = (kinfo_proc*)malloc(size);
    sysctl(mib,4,procs,&size,nullptr,0);
    int n = size / sizeof(kinfo_proc);
    std::vector<ProcessInfo> list;
    for (int i = 0; i < n; i++) {
        int pid = procs[i].kp_proc.p_pid;
        char name[PROC_PIDPATHINFO_MAXSIZE];
        proc_name(pid, name, sizeof(name));
        struct proc_taskinfo ti;
        if (proc_pidinfo(pid, PROC_PIDTASKINFO, 0, &ti, sizeof(ti)) > 0) {
            double mb = ti.pti_resident_size / 1e6;
            if (mb > 0.1) list.push_back({name, pid, mb});
        }
    }
    free(procs);
    std::sort(list.begin(), list.end(), [](auto &a, auto &b){ return a.memoryUsage > b.memoryUsage; });
    if (list.size() > size_t(count)) list.resize(count);
    return list;
}
#endif

std::string createProgressBar(double pct) {
    const std::string fullBlock = "█";
    const std::string emptyBlock = "░";
    int width = 20;
    int filled = static_cast<int>(pct / 100.0 * width);
    std::ostringstream o;
    o << "[";
    for (int i = 0; i < filled; ++i) o << fullBlock;
    for (int i = filled; i < width; ++i) o << emptyBlock;
    o << "] " << std::fixed << std::setprecision(1) << pct << "%";
    return o.str();
}

SystemInfo collectSystemInfo() {
#ifdef _WIN32
    SYSTEM_INFO si; GetSystemInfo(&si);
    auto ram = getRamUsage(), d = getDiskUsage();
    return {getCpuModel(), getGpuModel(), static_cast<int>(si.dwNumberOfProcessors), ram.second, d.second};
#else
    int cores = std::thread::hardware_concurrency();
    auto ram = getRamUsage(), d = getDiskUsage();
    std::string cpuModel;
#ifdef __linux__
    std::ifstream f("/proc/cpuinfo");
      std::string line;
      while (std::getline(f,line))
        if (line.rfind("model name",0)==0) { cpuModel=line.substr(line.find(":")+2); break; }
#elif defined(__APPLE__)
    char buf[256]; size_t sz=sizeof(buf);
    sysctlbyname("machdep.cpu.brand_string",buf,&sz,nullptr,0);
    cpuModel = buf;
#endif
    return {cpuModel, "Unknown GPU", cores, ram.second, d.second};
#endif
}

SystemMetrics getMetrics() {
    SystemMetrics m;
    m.cpuUsage = getCpuUsage();
    auto r = getRamUsage(); m.ramUsage=r.first; m.ramTotal=r.second;
    auto d = getDiskUsage(); m.diskUsage=d.first; m.diskTotal=d.second;
    m.gpuUsage = 0;
    m.topProcesses = getTopProcesses(10);
    return m;
}

void inputListener() {
    std::string s;
    while (running && std::getline(std::cin,s)) {
        if (s=="2") advancedMode=true;
        else if (s=="1") advancedMode=false;
        else if (s=="q") running=false;
    }
}

std::string basicDisplay(const SystemInfo& si, const SystemMetrics& m) {
    std::ostringstream o;
    o << "\033[2J\033[H";
    o << "=== Resource Monitor (" OS_NAME ") ===\n\n";
    o << "CPU Usage : " << createProgressBar(m.cpuUsage) << "\n";
    o << "RAM Usage : " << createProgressBar(m.ramUsage) << " [" << m.ramTotal << " GB Total]\n";
    o << "Disk Usage: " << createProgressBar(m.diskUsage) << " [" << m.diskTotal << " GB Total]\n";
    o << "\n[1] Basic View | [2] Advanced View | [q] Quit\n";
    o << "Mode: " << (advancedMode ? "Advanced" : "Basic") << "\n";
    return o.str();
}

std::string advancedDisplay(const SystemInfo& si, const SystemMetrics& m) {
    std::ostringstream o;
    o << "\033[2J\033[H";
    o << "=== Advanced Resource Monitor (" OS_NAME ") ===\n\n";
    o << "CPU Usage : " << createProgressBar(m.cpuUsage) << "\n";
    o << "RAM Usage : " << createProgressBar(m.ramUsage) << " [" << m.ramTotal << " GB Total]\n";
    o << "Disk Usage: " << createProgressBar(m.diskUsage) << " [" << m.diskTotal << " GB Total]\n";
    o << "CPU Model: " << si.cpuModel << "\n";
    o << "Cores    : " << si.totalCores << "\n";
    o << "RAM Total: " << si.totalRamGB << " GB\n";
    o << "GPU Model: " << si.gpuModel << "\n\n";
    o << std::left << std::setw(8) << "PID" << std::setw(25) << "Name" << std::setw(12) << "Mem (MB)\n";
    o << std::string(45, '-') << "\n";
    for (const auto &p : m.topProcesses) {
        o << std::setw(8) << p.pid
          << std::setw(25) << p.name.substr(0, 24)
          << std::fixed << std::setprecision(1) << std::setw(12) << p.memoryUsage << "\n";
    }
    o << "\n[1] Basic View | [2] Advanced View | [q] Quit\n";
    o << "Mode: " << (advancedMode ? "Advanced" : "Basic") << "\n";
    return o.str();
}

int main() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

    DWORD consoleMode = 0;
    if (!GetConsoleMode(h, &consoleMode)) {
        std::cerr << "Failed to get console mode\n";
        return 1;
    }

    consoleMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;

    if (!SetConsoleMode(h, consoleMode)) {
        std::cerr << "Failed to set console mode\n";
        return 1;
    }

    // PDH setup
    PdhOpenQuery(nullptr, 0, &cpuQuery);
    PdhAddCounter(cpuQuery, "\\Processor(_Total)\\% Processor Time", 0, &cpuTotal);
#endif

    SystemInfo si = collectSystemInfo();
    std::thread(inputListener).detach();

    while (running) {
        auto m = getMetrics();
        std::cout << (advancedMode ? advancedDisplay(si,m) : basicDisplay(si,m)) << std::flush;
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    std::cout << "\nMonitor terminated.\n";
    return 0;
}
